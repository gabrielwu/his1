-- phpMyAdmin SQL Dump
-- version 4.0.4.1
-- http://www.phpmyadmin.net
--
-- 主机: localhost
-- 生成日期: 2014 年 11 月 19 日 19:01
-- 服务器版本: 5.5.31
-- PHP 版本: 5.4.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `his`
--
CREATE DATABASE IF NOT EXISTS `his` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `his`;

-- --------------------------------------------------------

--
-- 表的结构 `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `username` varchar(40) DEFAULT NULL,
  `password` varchar(40) NOT NULL,
  `department_id` int(4) NOT NULL COMMENT '0:高级 其他：科室',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=13 ;

--
-- 转存表中的数据 `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`, `department_id`) VALUES
(7, 'gabrielwu', '202cb962ac59075b964b07152d234b70', 0),
(8, 'wk', '202cb962ac59075b964b07152d234b70', 1),
(10, 'nk', 'e10adc3949ba59abbe56e057f20f883e', 2),
(11, 'sjk', 'e10adc3949ba59abbe56e057f20f883e', 3),
(12, 'wk2', 'e10adc3949ba59abbe56e057f20f883e', 5);

-- --------------------------------------------------------

--
-- 表的结构 `department`
--

CREATE TABLE IF NOT EXISTS `department` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `inpatient_area_id` int(4) NOT NULL,
  `status` varchar(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- 转存表中的数据 `department`
--

INSERT INTO `department` (`id`, `name`, `inpatient_area_id`, `status`) VALUES
(1, '外科', 1, '1'),
(2, '内科', 2, '1'),
(3, '神经科', 3, '1'),
(4, '心脑血管科', 1, '1');

-- --------------------------------------------------------

--
-- 表的结构 `diagnosis`
--

CREATE TABLE IF NOT EXISTS `diagnosis` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `status` varchar(2) NOT NULL,
  `department_id` int(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- 转存表中的数据 `diagnosis`
--

INSERT INTO `diagnosis` (`id`, `name`, `status`, `department_id`) VALUES
(1, '冠心病', '1', 1),
(2, '败血症', '1', 2),
(3, '腰腿痛', '1', 1),
(4, '头皮损伤', '1', 1),
(5, '猛兽伤', '1', 1),
(6, '疾病2', '1', 1);

-- --------------------------------------------------------

--
-- 表的结构 `dictionary`
--

CREATE TABLE IF NOT EXISTS `dictionary` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `type_name` varchar(32) NOT NULL,
  `value` varchar(64) NOT NULL,
  `status` varchar(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `doctor`
--

CREATE TABLE IF NOT EXISTS `doctor` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL,
  `sex` varchar(2) NOT NULL,
  `birthday` date NOT NULL,
  `department_id` int(4) NOT NULL,
  `title_id` int(4) NOT NULL,
  `phone` varchar(12) NOT NULL,
  `speciality` text NOT NULL,
  `job_id` varchar(16) NOT NULL,
  `password` varchar(32) NOT NULL,
  `status` varchar(8) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `job_id` (`job_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- 转存表中的数据 `doctor`
--

INSERT INTO `doctor` (`id`, `name`, `sex`, `birthday`, `department_id`, `title_id`, `phone`, `speciality`, `job_id`, `password`, `status`) VALUES
(1, '外医生1', '男', '1978-09-01', 1, 1, '12312312123', '无', '123', '202cb962ac59075b964b07152d234b70', '1'),
(2, '外医生2', '男', '2014-09-24', 1, 1, '1', '1', '456', '250cf8b51c773f3f8dc8b4be867a9a02', '1'),
(3, '外医生3', '男', '1982-09-14', 1, 1, '1231', '等', '789', '68053af2923e00204c3ca7c6a3150cf7', '1'),
(5, '外医生4', '男', '2014-09-13', 1, 1, '1', '2', '012', 'd2490f048dc3b77a457e3e450ab4eb38', '0'),
(6, '张红', '女', '1990-09-01', 0, 3, '135733322232', '无', '1234', '81dc9bdb52d04dc20036dbd8313ed055', '1');

-- --------------------------------------------------------

--
-- 表的结构 `follow_up`
--

CREATE TABLE IF NOT EXISTS `follow_up` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `patient_id` int(8) NOT NULL,
  `description` text NOT NULL,
  `expectation` text NOT NULL,
  `create_time` datetime NOT NULL,
  `check_out_time` datetime DEFAULT NULL,
  `status` varchar(4) NOT NULL DEFAULT '0',
  `feedback` text NOT NULL,
  `check_doctor_id` int(8) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=13 ;

--
-- 转存表中的数据 `follow_up`
--

INSERT INTO `follow_up` (`id`, `patient_id`, `description`, `expectation`, `create_time`, `check_out_time`, `status`, `feedback`, `check_doctor_id`) VALUES
(1, 1, '', '', '2014-09-16 11:57:23', NULL, '1', '无', 1),
(4, 1, '', '', '2014-09-16 03:42:27', NULL, '0', '', 0),
(6, 2, 'qwe1', '21sd', '2014-09-16 03:46:06', NULL, '0', '', 0),
(8, 1, '', '', '2014-09-16 18:17:16', NULL, '1', '', 0),
(9, 1, '', '', '2014-09-16 19:36:56', NULL, '1', '', 0),
(10, 1, '', '', '2014-09-16 19:37:44', NULL, '1', '', 0),
(11, 1, '', '', '2014-09-21 21:55:25', NULL, '1', '无', 1),
(12, 1, '描述', '无', '2014-09-26 19:27:15', NULL, '1', 'www', 1);

-- --------------------------------------------------------

--
-- 表的结构 `follow_up_attachment`
--

CREATE TABLE IF NOT EXISTS `follow_up_attachment` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `follow_up_id` int(8) NOT NULL,
  `content` blob NOT NULL,
  `file_name` varchar(256) NOT NULL,
  `attachment_type_id` int(4) NOT NULL,
  `description` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=18 ;

--
-- 转存表中的数据 `follow_up_attachment`
--

INSERT INTO `follow_up_attachment` (`id`, `follow_up_id`, `content`, `file_name`, `attachment_type_id`, `description`) VALUES
(13, 9, '', '541820d5a4d65/jpg', 1, ''),
(14, 10, '', '541820ec0b841/jpg', 1, '9k'),
(15, 10, '', '541820ffb5ad7/jpg', 2, 'uu'),
(16, 12, '', '54254d743ad1e/jpg', 1, '胸片'),
(17, 12, '', '54254d8e442ee/jpg', 2, 'b');

-- --------------------------------------------------------

--
-- 表的结构 `follow_up_attachment_type`
--

CREATE TABLE IF NOT EXISTS `follow_up_attachment_type` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `status` varchar(2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- 转存表中的数据 `follow_up_attachment_type`
--

INSERT INTO `follow_up_attachment_type` (`id`, `name`, `status`) VALUES
(1, '胸片', '1'),
(2, 'B超', '1'),
(3, '血常规', '1'),
(4, 'CT', '1');

-- --------------------------------------------------------

--
-- 表的结构 `follow_up_medication`
--

CREATE TABLE IF NOT EXISTS `follow_up_medication` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `follow_up_id` int(8) NOT NULL,
  `medicine_id` int(8) NOT NULL,
  `medicine_frequency_id` int(4) NOT NULL,
  `medicine_usage_id` int(4) NOT NULL,
  `medicine_dose` float NOT NULL,
  `medicine_unit_id` int(4) NOT NULL,
  `begin_time` date NOT NULL,
  `end_time` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=15 ;

--
-- 转存表中的数据 `follow_up_medication`
--

INSERT INTO `follow_up_medication` (`id`, `follow_up_id`, `medicine_id`, `medicine_frequency_id`, `medicine_usage_id`, `medicine_dose`, `medicine_unit_id`, `begin_time`, `end_time`) VALUES
(1, 1, 1, 1, 1, 1, 1, '2014-09-30', '2014-09-30'),
(2, 1, 2, 2, 1, 2, 1, '2014-09-29', '2012-09-12'),
(3, 2, 1, 1, 1, 3, 1, '2014-09-30', '2014-09-29'),
(5, 4, 1, 1, 1, 3, 1, '2014-09-24', '2014-09-30'),
(7, 6, 1, 1, 2, 2, 1, '2014-09-30', '2014-09-30'),
(9, 8, 1, 2, 1, 1, 1, '2014-09-01', '2014-09-01'),
(10, 10, 1, 1, 1, 9, 1, '2014-09-02', '2014-09-16'),
(11, 10, 3, 2, 2, 7.8, 3, '2014-09-02', '2014-09-02'),
(12, 11, 1, 1, 1, 0, 1, '0000-00-00', '0000-00-00'),
(13, 12, 1, 1, 1, 3, 1, '2014-09-03', '2014-09-26'),
(14, 12, 1, 2, 1, 2, 1, '2014-09-04', '2014-09-18');

-- --------------------------------------------------------

--
-- 表的结构 `inpatient_area`
--

CREATE TABLE IF NOT EXISTS `inpatient_area` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `status` varchar(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- 转存表中的数据 `inpatient_area`
--

INSERT INTO `inpatient_area` (`id`, `name`, `status`) VALUES
(1, '一病区', '1'),
(2, '二病区', '1'),
(3, '三病区', '1'),
(4, '四病区', '1'),
(6, '五病区', '1');

-- --------------------------------------------------------

--
-- 表的结构 `medicine`
--

CREATE TABLE IF NOT EXISTS `medicine` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `status` varchar(2) NOT NULL,
  `department_id` int(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- 转存表中的数据 `medicine`
--

INSERT INTO `medicine` (`id`, `name`, `status`, `department_id`) VALUES
(1, '阿莫西林', '1', 1),
(2, '阿莫西林2', '1', 1),
(3, '白加黑', '1', 1),
(4, '药物2', '1', 1);

-- --------------------------------------------------------

--
-- 表的结构 `medicine_frequency`
--

CREATE TABLE IF NOT EXISTS `medicine_frequency` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `value` varchar(32) NOT NULL,
  `status` varchar(2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- 转存表中的数据 `medicine_frequency`
--

INSERT INTO `medicine_frequency` (`id`, `value`, `status`) VALUES
(1, '一天三次', '1'),
(2, '一天一次，早上服用', '1'),
(3, '一天一次', '1');

-- --------------------------------------------------------

--
-- 表的结构 `medicine_unit`
--

CREATE TABLE IF NOT EXISTS `medicine_unit` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `name` varchar(16) NOT NULL,
  `status` varchar(2) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- 转存表中的数据 `medicine_unit`
--

INSERT INTO `medicine_unit` (`id`, `name`, `status`) VALUES
(1, '克g', '1'),
(2, '毫克mg', '1'),
(3, '毫升ml', '1'),
(4, '片', '1'),
(5, '瓶', '1');

-- --------------------------------------------------------

--
-- 表的结构 `medicine_usage`
--

CREATE TABLE IF NOT EXISTS `medicine_usage` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `value` varchar(16) NOT NULL,
  `status` varchar(2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- 转存表中的数据 `medicine_usage`
--

INSERT INTO `medicine_usage` (`id`, `value`, `status`) VALUES
(1, '口服', '1'),
(2, '皮下注射', '1'),
(3, '静脉', '1');

-- --------------------------------------------------------

--
-- 表的结构 `operation`
--

CREATE TABLE IF NOT EXISTS `operation` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `patient_id` int(8) NOT NULL,
  `operation_type_id` int(4) NOT NULL,
  `operator_id` int(8) NOT NULL,
  `assistant1_id` int(8) NOT NULL,
  `assistant2_id` int(8) NOT NULL,
  `begin_time` datetime NOT NULL,
  `end_time` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- 转存表中的数据 `operation`
--

INSERT INTO `operation` (`id`, `patient_id`, `operation_type_id`, `operator_id`, `assistant1_id`, `assistant2_id`, `begin_time`, `end_time`) VALUES
(3, 1, 5, 1, 3, 5, '2014-09-01 00:00:00', '2014-09-01 01:00:00'),
(4, 2, 2, 1, 3, 2, '2014-09-01 13:22:22', '2014-09-01 14:22:22'),
(5, 1, 5, 1, 2, 3, '2014-09-23 13:00:00', '2014-09-23 14:00:00');

-- --------------------------------------------------------

--
-- 表的结构 `operation_detail`
--

CREATE TABLE IF NOT EXISTS `operation_detail` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `operation_id` int(8) NOT NULL,
  `father_field_id` int(8) NOT NULL,
  `field` text NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=15 ;

--
-- 转存表中的数据 `operation_detail`
--

INSERT INTO `operation_detail` (`id`, `operation_id`, `father_field_id`, `field`, `value`) VALUES
(6, 3, 3, '3', '否'),
(7, 3, 4, '4', '是'),
(8, 3, 5, '5', '0.2'),
(9, 3, 13, '13', 'LAD'),
(10, 3, 13, '13', 'LAD,LCX,RCA'),
(11, 4, 3, '3', '是'),
(12, 4, 4, '4', '是'),
(13, 4, 5, '5', '0.1'),
(14, 4, 13, '13', 'LAD,动脉桥');

-- --------------------------------------------------------

--
-- 表的结构 `operation_field`
--

CREATE TABLE IF NOT EXISTS `operation_field` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `department_id` int(4) NOT NULL,
  `format` varchar(64) NOT NULL,
  `type` varchar(2) NOT NULL,
  `value_options` text NOT NULL,
  `multiple` varchar(2) NOT NULL,
  `status` varchar(2) NOT NULL,
  `father_id` int(8) NOT NULL,
  `search` varchar(2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=18 ;

--
-- 转存表中的数据 `operation_field`
--

INSERT INTO `operation_field` (`id`, `name`, `department_id`, `format`, `type`, `value_options`, `multiple`, `status`, `father_id`, `search`) VALUES
(1, '球囊', 1, '', '2', 'b.braun,sprinter,yinyi,kongou,durastar', '1', '1', 0, '0'),
(2, '手术入路', 1, '', '2', '右侧桡动脉,右侧股动脉,左侧桡动脉,左侧股动脉,右侧股静脉,左侧股静脉', '0', '1', 0, '0'),
(3, 'IVUS', 1, '', '2', '是,否', '0', '1', 0, '1'),
(4, 'OCT', 1, '', '2', '是,否', '0', '1', 0, '1'),
(5, 'FFR', 1, '百分数，如0.01', '1', '', '1', '1', 0, '1'),
(6, '导丝', 1, '', '2', 'runthrough,bmw,rinato,conquest,pilot,crossit', '1', '1', 0, '0'),
(7, '支架', 1, '', '2', '强生,波士顿', '1', '1', 0, '0'),
(8, '球囊长度（mm）', 1, '', '2', '10,15,20', '0', '1', 1, '0'),
(9, '球囊半径', 1, '', '2', '1.25,1.5,2.0,2.5,3.0,3.5,4.0', '0', '1', 1, '0'),
(10, '球囊类型', 1, '', '2', '顺应型,非顺应型,半顺应型,双导丝,切割', '0', '1', 1, '0'),
(11, '支架长度（mm）', 1, '', '2', '8,12,18,23,24,28,33,36', '0', '1', 7, '0'),
(12, '支架直径', 1, '', '2', '2.25,2.5,2.75,3.0,3.5,4.0,4.5,5.0', '0', '1', 7, '0'),
(13, '血管病变位置', 1, '', '3', 'LAD,LCX,RCA,LM,中间支,动脉桥,静脉桥,畸形冠状动脉', '1', '1', 0, '0'),
(14, 'PCI靶血管', 1, '', '3', 'LM,LM-LAD,LAD,LM-LCX,LCX,RCA,LM-中间支,动脉桥,静脉桥,畸形冠状动脉', '1', '1', 0, '0'),
(15, '支架数量', 1, '', '1', '', '0', '1', 7, '0'),
(16, '手术入路', 2, '', '2', '动脉,静脉', '0', '1', 0, '0'),
(17, '支架品牌', 1, '', '2', '强生,波士顿', '1', '1', 7, '1');

-- --------------------------------------------------------

--
-- 表的结构 `operation_type`
--

CREATE TABLE IF NOT EXISTS `operation_type` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `status` varchar(2) NOT NULL,
  `department_id` int(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- 转存表中的数据 `operation_type`
--

INSERT INTO `operation_type` (`id`, `name`, `status`, `department_id`) VALUES
(1, 'PCI', '1', 1),
(2, '冠状造影', '1', 1),
(4, '射频消融术', '1', 1),
(5, '永久起搏器植入', '1', 1),
(6, '先天性心脏病封堵', '1', 1),
(7, '内科手术1', '1', 2),
(8, '电生理检查', '1', 1);

-- --------------------------------------------------------

--
-- 表的结构 `operation_type_field`
--

CREATE TABLE IF NOT EXISTS `operation_type_field` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `operation_type_id` int(8) NOT NULL,
  `operation_field_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=46 ;

--
-- 转存表中的数据 `operation_type_field`
--

INSERT INTO `operation_type_field` (`id`, `operation_type_id`, `operation_field_id`) VALUES
(20, 2, 3),
(21, 2, 4),
(22, 2, 5),
(23, 2, 13),
(24, 3, 3),
(25, 3, 4),
(26, 3, 5),
(27, 3, 13),
(28, 4, 3),
(29, 4, 4),
(30, 4, 5),
(31, 4, 13),
(32, 5, 3),
(33, 5, 4),
(34, 5, 5),
(35, 5, 13),
(36, 6, 3),
(37, 6, 4),
(38, 6, 5),
(39, 6, 13),
(40, 7, 16),
(41, 1, 1),
(42, 1, 5),
(43, 1, 6),
(44, 1, 7),
(45, 1, 14);

-- --------------------------------------------------------

--
-- 表的结构 `patient`
--

CREATE TABLE IF NOT EXISTS `patient` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `medical_id` varchar(32) CHARACTER SET utf8 NOT NULL,
  `password` varchar(32) CHARACTER SET utf8 NOT NULL,
  `name` varchar(32) CHARACTER SET utf8 NOT NULL,
  `sex` varchar(2) CHARACTER SET utf8 NOT NULL,
  `birthday` date DEFAULT NULL,
  `age` int(3) DEFAULT NULL,
  `phone` varchar(12) CHARACTER SET utf8 NOT NULL,
  `email` varchar(32) CHARACTER SET utf8 NOT NULL,
  `id_type` varchar(32) COLLATE utf8_estonian_ci NOT NULL,
  `id_number` varchar(32) CHARACTER SET utf8 NOT NULL,
  `job` varchar(16) CHARACTER SET utf8 NOT NULL,
  `marital_status` varchar(16) COLLATE utf8_estonian_ci NOT NULL,
  `nation` varchar(32) COLLATE utf8_estonian_ci NOT NULL,
  `native_place` varchar(64) CHARACTER SET utf8 NOT NULL,
  `blood_type` varchar(2) CHARACTER SET utf8 NOT NULL,
  `address` varchar(128) CHARACTER SET utf8 NOT NULL,
  `postcode` int(6) NOT NULL,
  `temperature` float NOT NULL,
  `pulse` float NOT NULL,
  `breath` int(11) NOT NULL,
  `blood_pressure` varchar(32) CHARACTER SET utf8 NOT NULL,
  `specialized_examination` text CHARACTER SET utf8 NOT NULL,
  `examination_remark` text CHARACTER SET utf8 NOT NULL,
  `department_id` int(4) NOT NULL,
  `attending_doctor_id` int(8) NOT NULL,
  `diagnosis_id` int(8) NOT NULL,
  `admission_time` date NOT NULL,
  `inpatient` varchar(2) CHARACTER SET utf8 NOT NULL,
  `operation` varchar(2) CHARACTER SET utf8 NOT NULL,
  `complaint` text CHARACTER SET utf8 NOT NULL,
  `history_allergy` text CHARACTER SET utf8 NOT NULL,
  `history_present` text CHARACTER SET utf8 NOT NULL,
  `history_previous` text CHARACTER SET utf8 NOT NULL,
  `history_personal` text CHARACTER SET utf8 NOT NULL,
  `history_family` text CHARACTER SET utf8 NOT NULL,
  `remark` text CHARACTER SET utf8 NOT NULL,
  `room` text CHARACTER SET utf8 NOT NULL,
  `bed` text CHARACTER SET utf8 NOT NULL,
  `inpatient_id` text CHARACTER SET utf8 NOT NULL,
  `in_date` date NOT NULL,
  `out_date` date NOT NULL,
  `charge_doctor_id` int(8) NOT NULL,
  `professor_id` int(8) NOT NULL,
  `time_update` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_estonian_ci AUTO_INCREMENT=7 ;

--
-- 转存表中的数据 `patient`
--

INSERT INTO `patient` (`id`, `medical_id`, `password`, `name`, `sex`, `birthday`, `age`, `phone`, `email`, `id_type`, `id_number`, `job`, `marital_status`, `nation`, `native_place`, `blood_type`, `address`, `postcode`, `temperature`, `pulse`, `breath`, `blood_pressure`, `specialized_examination`, `examination_remark`, `department_id`, `attending_doctor_id`, `diagnosis_id`, `admission_time`, `inpatient`, `operation`, `complaint`, `history_allergy`, `history_present`, `history_previous`, `history_personal`, `history_family`, `remark`, `room`, `bed`, `inpatient_id`, `in_date`, `out_date`, `charge_doctor_id`, `professor_id`, `time_update`) VALUES
(1, '111222333', '6e0cb332feab4ee69c74af9396c104f0', '张思', '男', '1988-01-31', 26, '13422332233', '5555@qq.com', '身份证', '130220198801312233', '学生', '未婚', '汉族', '河北', 'A', '长春', 130012, 37, 70, 21, '140', '专科查体', '其他', 1, 1, 1, '2014-09-02', '是', '是', '主诉', '过敏时', '现病史', '既往是', '个人史', '家族', '备注', '122', '2', '111222333', '2014-09-03', '2014-09-27', 3, 1, '2014-09-28 08:03:28'),
(2, '1111', '', '李四', '', '0000-00-00', 25, '13678917898', '', '', '130202198904140039', '', '0', '0', '', '', '', 0, 0, 0, 0, '', '', '', 1, 2, 1, '2014-09-03', '否', '否', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, '2014-09-26 03:32:26'),
(3, '123111', '', '赵六', '男', '0000-00-00', 22, '111', '', '身份证', '103202199902223333', '', '', '', '', '', '', 0, 0, 0, 0, '', '', '', 0, 0, 0, '0000-00-00', '', '', '', '', '', '', '', '', '', '', '', '', '0000-00-00', '0000-00-00', 0, 0, '2014-09-23 02:07:02'),
(5, '123123', '7bcbc6826654907d7e1aebf014511b49', '王五', '女', '2014-09-02', 2, '4444', '33333@qq.com', '身份证', '13020220140902', '学生', '未婚', '汉族', '222', 'A', '2222', 2222, 36, 44, 22, '123', '阿啊啊', '得到', 0, 3, 2, '2014-09-02', '是', '是', '11111', '11111', '11111', '11111', '111111', '11111', '11111', '1', '1', '1', '2014-09-03', '2014-09-03', 1, 3, '2014-09-23 01:48:28'),
(6, '140314', '4297f44b13955235245b2497399d7a93', '王涛', '男', '1988-09-16', 26, '13444332233', '', '身份证', '130202198809162233', '', '', '', '', 'A', '', 0, 37, 76, 23, '144', '无', '无', 0, 1, 2, '2014-09-04', '是', '是', '无', '1', '2', '3', '4', '5', '56', '22', '2', '140314', '2014-09-03', '2014-09-26', 2, 1, '2014-09-26 11:56:14');

-- --------------------------------------------------------

--
-- 表的结构 `patient_medication`
--

CREATE TABLE IF NOT EXISTS `patient_medication` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `patient_id` int(8) NOT NULL,
  `medicine_id` int(8) NOT NULL,
  `medicine_frequency_id` int(4) NOT NULL,
  `medicine_usage_id` int(4) NOT NULL,
  `medicine_dose` float NOT NULL,
  `medicine_unit_id` int(4) NOT NULL,
  `begin_time` date NOT NULL,
  `end_time` date NOT NULL,
  `days` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=37 ;

--
-- 转存表中的数据 `patient_medication`
--

INSERT INTO `patient_medication` (`id`, `patient_id`, `medicine_id`, `medicine_frequency_id`, `medicine_usage_id`, `medicine_dose`, `medicine_unit_id`, `begin_time`, `end_time`, `days`) VALUES
(25, 1, 1, 1, 1, 1, 1, '2014-09-30', '2014-09-30', 1),
(26, 1, 2, 1, 1, 3, 1, '2014-09-30', '2014-09-29', 0),
(27, 1, 1, 1, 1, 100, 1, '2014-09-22', '2014-09-24', 3),
(28, 5, 1, 1, 1, 2, 1, '2014-09-02', '2014-09-25', 24),
(29, 3, 1, 1, 1, 2, 1, '2014-09-03', '2014-09-11', 9),
(30, 2, 3, 1, 1, 2, 1, '2014-09-03', '2014-09-10', 8),
(35, 6, 1, 1, 1, 2, 1, '2014-09-03', '2014-09-26', 24),
(36, 6, 2, 3, 2, 2, 2, '2014-09-03', '2014-09-04', 2);

-- --------------------------------------------------------

--
-- 表的结构 `title`
--

CREATE TABLE IF NOT EXISTS `title` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `name` varchar(16) NOT NULL,
  `status` varchar(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- 转存表中的数据 `title`
--

INSERT INTO `title` (`id`, `name`, `status`) VALUES
(1, '主任医师', '1'),
(2, '副主任医师', '1'),
(3, '主治医生', '1');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
